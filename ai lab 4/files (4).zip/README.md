# Lab 4: Informed Search - Heuristics and A*

**Student:** Rasikh Ali | **Roll No:** 42365 | **Course:** CAI601400 Artificial Intelligence Lab | **CLO2 (C3: Apply)**

## What this lab does
Implements A* with a priority queue (`heapq`) on a weighted campus graph and:
1. Traces g, h and f for the first three expansions.
2. Compares A* with a zero-heuristic UCS control (same graph, endpoints, tie-breaking).
3. Overestimates one heuristic value (h(C): 2 -> 10) and shows the optimality guarantee breaking.
It also audits the heuristic for admissibility and consistency.

## Files
| File | Purpose |
|---|---|
| `lab4_astar_audit.py` | Source code (A*, UCS control, heuristic audit, overestimate test) |
| `lab4_output.txt` | Captured output of the script (trace, audit, comparison) |
| `Lab4_Report.docx` | Full report |
| `README.md` | This file |

## Setup and run
Requires Python 3.8+ and the standard library only (no installs, no virtual environment needed).
```
python lab4_astar_audit.py
python lab4_astar_audit.py > lab4_output.txt   # to regenerate the captured output
```

## Input data (hard-coded at the top of the script)
- Graph (directed, travel-time units): S->A 1, S->B 4, A->C 2, B->G 5, C->G 3
- Start S, goal G
- Heuristic: h(S)=5, h(A)=4, h(B)=4, h(C)=2, h(G)=0
- True remaining costs: S 6, A 5, B 5, C 3, G 0
- Overestimate experiment: only h(C) changed from 2 to 10

## Conventions
- Queue entries are `(f, g, node, path)`; ties break on lower g, then node name.
- A node is "expanded" only when its successors are examined. The goal is logged but not counted. Stale entries are skipped.

## Expected results
| Run | Path | Cost | Expanded |
|---|---|---|---|
| A* (supplied h) | S-A-C-G | 6 | 3 |
| UCS (h = 0) | S-A-C-G | 6 | 4 |
| A* with h(C) = 10 | S-B-G | 9 | 3 |

## Sources
Graph, heuristic values and the base A* code are from the course lab manual (CAI601400 Lab 4, Week 4). The audit, trace and comparison code was extended for this submission. No other external code or data was used.

## Notes
No credentials, private information or virtual environments are included.
