"""Lab 4: Informed Search - A* with heuristic audit, UCS control, overestimate test.

Run:  python lab4_astar_audit.py
Queue entries are (f, g, node, path): ties break on lower g, then node name.
Counting convention: a node is "expanded" only when its successors are examined.
The goal is logged in the trace but NOT counted. Stale queue entries are skipped.
"""
import heapq

GRAPH = {"S": [("A", 1), ("B", 4)], "A": [("C", 2)],
         "B": [("G", 5)], "C": [("G", 3)], "G": []}
H = {"S": 5, "A": 4, "B": 4, "C": 2, "G": 0}
TRUE_COST = {"S": 6, "A": 5, "B": 5, "C": 3, "G": 0}   # true remaining cost to G


def astar(graph, h, start, goal, verbose=False):
    pq = [(h[start], 0, start, [start])]
    best = {start: 0}
    trace, expanded, stale = [], 0, 0
    while pq:
        f, g, node, path = heapq.heappop(pq)
        if g != best[node]:                    # stale entry
            stale += 1
            continue
        trace.append(node)
        if node == goal:                       # goal logged, not counted
            return {"cost": g, "path": path, "trace": trace,
                    "expanded": expanded, "stale": stale}
        expanded += 1
        if verbose:
            print(f"  Expansion {expanded}: node={node} g={g} h={h[node]} "
                  f"f={g}+{h[node]}={f}")
        for nxt, w in graph.get(node, []):
            ng = g + w
            if ng < best.get(nxt, float("inf")):
                best[nxt] = ng
                heapq.heappush(pq, (ng + h[nxt], ng, nxt, path + [nxt]))
                if verbose:
                    print(f"      push {nxt}: g={g}+{w}={ng}, h={h[nxt]}, "
                          f"f={ng}+{h[nxt]}={ng + h[nxt]}")
        if verbose:
            fr = sorted((e[0], e[1], e[2]) for e in pq if e[1] == best[e[2]])
            print("      frontier (f,g,node):", fr)
    return None


def path_cost(graph, path):
    """Independent sum of edge weights along a path."""
    return sum(dict(graph[a])[b] for a, b in zip(path, path[1:]))


def audit(graph, h, true_cost):
    print("Consistency check  h(u) <= cost(u,v) + h(v):")
    ok_c = True
    for u, edges in graph.items():
        for v, w in edges:
            ok = h[u] <= w + h[v]
            ok_c &= ok
            print(f"  {u}->{v}: {h[u]} <= {w}+{h[v]}={w + h[v]}  {'PASS' if ok else 'FAIL'}")
    print("Admissibility check  h(n) <= true remaining cost:")
    ok_a = True
    for n in h:
        ok = h[n] <= true_cost[n]
        ok_a &= ok
        print(f"  {n}: h={h[n]} <= true={true_cost[n]}  {'PASS' if ok else 'FAIL'}")
    print(f"Consistent: {ok_c} | Admissible: {ok_a}")


def report(name, graph, h):
    r = astar(graph, h, "S", "G")
    print(f"{name:<18} path={'->'.join(r['path'])}  cost={r['cost']} "
          f"(summed={path_cost(graph, r['path'])})  trace={r['trace']}  "
          f"expanded={r['expanded']}  stale={r['stale']}")
    return r


if __name__ == "__main__":
    print("=== TASK 1: manual-trace check (A*, supplied h) ===")
    astar(GRAPH, H, "S", "G", verbose=True)
    print("\n--- Heuristic audit ---")
    audit(GRAPH, H, TRUE_COST)

    print("\n=== TASK 2: A* vs UCS (same graph, endpoints, tie-breaking) ===")
    zero_h = {n: 0 for n in H}
    a = report("A* (supplied h)", GRAPH, H)
    u = report("UCS (h=0)", GRAPH, zero_h)
    saved = u["expanded"] - a["expanded"]
    print(f"Expansion difference: {saved} fewer for A* "
          f"({saved / u['expanded']:.0%}) on this instance only.")

    print("\n=== TASK 3: overestimate h(C): 2 -> 10 (true remaining = 3) ===")
    h_bad = {**H, "C": 10}
    print(f"Original h(C)={H['C']}, modified h(C)={h_bad['C']}, true={TRUE_COST['C']}")
    b = report("A* h(C)=10", GRAPH, h_bad)
    print(f"Path changed: {a['path'] != b['path']} | Cost changed: "
          f"{a['cost'] != b['cost']} | Expansions changed: "
          f"{a['expanded'] != b['expanded']}")
    print("Consistency on C->G:", h_bad["C"], "<=", 3 + h_bad["G"], "->",
          h_bad["C"] <= 3 + h_bad["G"])

    print("\n--- Extra: overestimate that does NOT break this run (h(C)=4) ---")
    c = report("A* h(C)=4", GRAPH, {**H, "C": 4})
    print("Still optimal here only because f(C)=3+4=7 < f(B)=8; "
          "overestimate is still inadmissible.")
